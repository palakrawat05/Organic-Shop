export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCxLWu6VIcfFWYM6j2Rzcj2x-oIXHBdT04",
    authDomain: "ogshoper.firebaseapp.com",
    projectId: "ogshoper",
    storageBucket: "ogshoper.appspot.com",
    databaseURL:"https://ogshoper-default-rtdb.firebaseio.com",
    messagingSenderId: "906459568349",
    appId: "1:906459568349:web:b3ba096e20e4748371e334",
    measurementId: "G-TZDKVG9ZKJ"    
  }
};
